-- AlterTable
ALTER TABLE "Bounty" ADD COLUMN     "songUrl" TEXT;
