-- AlterTable
ALTER TABLE "Video" ADD COLUMN     "key" TEXT;
